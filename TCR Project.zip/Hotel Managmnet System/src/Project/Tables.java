/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project;

import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author latis
 */
public class Tables {
    public static void main(String[]args)
    {
        Connection con=null;
        Statement st = null;
        
        try
        {
            con=ConnectionProvider.getCon();
            st=con.createStatement();
            st.executeUpdate("create table users(Name varchar(200),Email varchar(200),Password varchar(50),SecurityQuestion varchar(500),Answer varchar(200),Address varchar(200),Status varchar(20))");
            st.executeUpdate("create table room(roomNo varchar(10),roomType varchar(200),bed varchar(200),price int,status varchar(20))");
            st.executeUpdate("create table Customer(Id int, Name varchar(200),MobileNumber varchar(20),Nationality varchar(200),Gender varchar(50),Email varchar(200),IdProof varchar(200),Address varchar(500),CheckIn varchar(50),roomNo varchar(10),bed varchar(200),roomType varchar(200),PricePerDay int(10),NumberOfDaysStay int(10),TotalAmount varchar(200),CheckOut varchar(50)) ");
            JOptionPane.showMessageDialog(null, "Table Created Successfully");
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
        finally
        {
             try
        {
                con.close();
                st.close();
        }
        catch(Exception e)
        {
        }
        }
    }
    
}
